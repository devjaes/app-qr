export interface MetaDataColumn {
  field:string;
  title:string;
}
