export interface DomainData extends BaseData {
  id: number;
}

export interface BaseData { }

export interface AppData extends BaseData {
  _id: number;
}
