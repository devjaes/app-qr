export interface KeypadButton {
  icon:string;
  color:string;
  tooltip:string;
  action:string;
}
