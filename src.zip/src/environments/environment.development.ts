export const environment = {
  PAGE_SIZE: 10,
  API_URL: 'http://localhost:3000',
  firebaseConfig: {
    apiKey: "AIzaSyAmnUx7MHz4TEdgdmelsvPC4naJiTLv21g",
    authDomain: "app-qr-91516.firebaseapp.com",
    projectId: "app-qr-91516",
    storageBucket: "app-qr-91516.appspot.com",
    messagingSenderId: "768391571908",
    appId: "1:768391571908:web:73bdf258c3e42d7026dc91"
  }
};
