export const environment = {
  PAGE_SIZE: 10,
};
